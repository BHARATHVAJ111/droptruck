@extends('layouts.sidebar')

@section('content')
<style type="text/css">
    .section {
            width: 50%; /* Each section takes half of the width */
            float: left; /* Float the sections to make them appear side by side */
            box-sizing: border-box; /* Include padding and border in the element's total width and height */
            padding: 20px; /* Add some padding for spacing */
        }
</style>

<div class="main mb-4 mt-1">
    <div class="row align-items-center">
        <div class="col">
            <div class="d-flex">
                <button type="button" class="btn dash1"  style="margin-left:600px">
                @if(auth()->user()->role_id == 4)
                <a href="{{ route('loading') }}" class="text-decoration-none text-dark"> Back</a>
                @else
                <a href="/trips" class="text-decoration-none text-dark"> Back</a>
                @endif
            </button>
            </div>
        </div>
   
        <div class="col-lg-12 mt-5" style="background-color:#D9D9D9">
                <div class="section">
                    <h3>Driver Information</h3>
                    <ul class="list-unstyled">
                        <li class="row">
                            <strong class="col-sm-3">Driver Name</strong>
                            <span class="col-sm-7">{{ $driver->driver_name }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Driver Number</strong>
                            <span class="col-sm-7">{{ $driver->driver_number }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Vehicle Number</strong>
                            <span class="col-sm-7">{{ $driver->vehicle_number }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Vehicle Photo</strong>
                            <span class="col-sm-7">
                                <a href="{{ asset('/' . $driver->vehicle_photo) }}" target="_blank" class="text-decoration-underline">
                                    Vehicle Photo
                                </a>
                                <a href="{{ asset('/' . $driver->vehicle_photo) }}" download="{{ asset('/' . $driver->vehicle_photo) }}">
                                    <i class="fas fa-download"></i>
                                </a><br>
                            </span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Driver License</strong>
                            <span class="col-sm-7">
                                <a href="{{ asset('/' . $driver->driver_license) }}" target="_blank" class="text-decoration-underline">
                                    Driver License
                                </a>
                                <a href="{{ asset('/' . $driver->driver_license) }}" download="{{ asset('/' . $driver->driver_license) }}">
                                    <i class="fas fa-download"></i>
                                </a>
                                <br>
                            </span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">RC Book</strong>
                            <span class="col-sm-7">
                                <a href="{{ asset('/' . $driver->rc_book) }}" target="_blank" class="text-decoration-underline">
                                    RC Book
                                </a>
                                <a href="{{ asset('/' . $driver->rc_book) }}" download="{{ asset('/' . $driver->rc_book) }}">
                                    <i class="fas fa-download"></i>
                                </a><br>
                            </span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Insurance</strong>
                            <span class="col-sm-7">
                                <a href="{{ asset('/' . $driver->insurance) }}" target="_blank" class="text-decoration-underline">
                                    Insurance
                                </a>
                                <a href="{{ asset('/' . $driver->insurance) }}" download="{{ asset('/' . $driver->insurance) }}">
                                    <i class="fas fa-download"></i>
                                </a><br>
                            </span>
                        </li>
                    </ul>
                </div>
               @if($suppliers)
                <div class="section">
                    <h3>Supplier Information</h3>
                    <ul class="list-unstyled" style="margin: 0; padding: 0;">
                        <li class="row">
                            <strong class="col-sm-3">Supplier Name</strong>
                            <span class="col-sm-7">{{ $suppliers->supplier_name }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Supplier Type</strong>
                            <span class="col-sm-7">{{ $suppliers->supplier_type }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Company Name</strong>
                            <span class="col-sm-7">{{ $suppliers->company_name }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Bank Name</strong>
                            <span class="col-sm-7">{{ $suppliers->bank_name }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">IFSC Code</strong>
                            <span class="col-sm-7">{{ $suppliers->ifsc_code }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Account Number</strong>
                            <span class="col-sm-7">{{ $suppliers->account_number }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Pan Card Number</strong>
                            <span class="col-sm-7">{{ $suppliers->pan_card_number }}</span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Pancard</strong>
                            <span class="col-sm-7">
                                <a href="{{ asset('/' . $suppliers->pan_card) }}" target="_blank" class="text-decoration-underline">
                                    Pancard
                                </a>
                                <a href="{{ asset('/' . $suppliers->pan_card) }}" download="{{ asset('/' . $suppliers->pan_card) }}">
                                    <i class="fas fa-download"></i>
                                </a><br>
                            </span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Bank Details</strong>
                            <span class="col-sm-7">
                                
                            </span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Business Card</strong>
                            <span class="col-sm-7">
                                <a href="{{ asset('/' . $suppliers->business_card) }}" target="_blank" class="text-decoration-underline">
                                    Business Card
                                </a>
                                <a href="{{ asset('/' . $suppliers->business_card) }}" download="{{ asset('/' . $suppliers->business_card) }}">
                                    <i class="fas fa-download"></i>
                                </a><br>
                            </span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Others</strong>
                            <span class="col-sm-7">
                            </span>
                        </li>
                         <li class="row">
                            <strong class="col-sm-3">Tracking Link</strong>
                            <span class="col-sm-7">
                                <a href="" target="_blank" class="text-decoration-underline">
                                    Tracking
                                </a>
                            </span>
                        </li>
                        <li class="row">
                            <strong class="col-sm-3">Driver Advcne paid</strong>
                            <span class="col-sm-7">
                            {{ ($suppliersAdvanceAmt)?$suppliersAdvanceAmt->advance_amount:'00.00' }}
                            </span>
                        </li>
                    </ul>
                </div>
            @endif
        </div>
       
    </div>
</div>

@endsection