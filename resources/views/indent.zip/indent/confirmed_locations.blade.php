@extends('layouts.sidebar')

@section('content')
<style>
    th {
        color: blueviolet;
    }

    .btn-warning.custom-active {
        background: linear-gradient(135deg, #007bff, #8a2be2);
        color: #fff;
        border: #8a2be2;
    }

    .bg-gradient-info {
        background-image: radial-gradient(515px at 48.7% 52.8%, rgb(239, 110, 110) 0%, rgb(230, 25, 25) 46.5%, rgb(154, 11, 11) 100.2%);
    }
    .circle-badge {
        border-radius: 50%;
    }
</style>
<div class="m-3">
    <a href="{{ route('indents.index') }}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px;position: relative;">Unquoted<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
            {{ $unquotedIndents->count() }}
    </span></a>
    <a href="{{ route('fetch-last-two-details') }}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px;position: relative;">Quoted<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
            {{ $quotedIndents->count() }}
    </span></a>
    <a href="{{ route('confirmed_locations')}}" class="btn btn-warning custom-active" style="font-size: 12px; padding: 5px 10px;position: relative;">Confirmed
    <span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
    {{ $indents->count() }}
    </span>
</a>
    <a href="{{ route('canceled-indents') }}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px;position: relative;">Cancel<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
            {{ $canceledIndents }}
    </span></a>
</div>

<table class="table table-bordered table-striped table-hover" style="font-size:8px;">
    <thead>
        <tr>
            <th class="bg-gradient-info text-light">Enq No</th>
            <th class="bg-gradient-info text-light">Customer Name</th>
            <th class="bg-gradient-info text-light">Company Name</th>
            <th class="bg-gradient-info text-light">Number 1</th>
            <th class="bg-gradient-info text-light">Pickup Location</th>
            <th class="bg-gradient-info text-light">Drop Location</th>
            <th class="bg-gradient-info text-light">Material Type</th>
            <th class="bg-gradient-info text-light">Truck Type</th>
            <th class="bg-gradient-info text-light">Rate</th>
            <th class="bg-gradient-info text-light">Customer Rate</th>
            <th class="bg-gradient-info text-light">Remarks</th>
            <th class="bg-gradient-info text-light">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($indents as $confirmedIndent)
        <tr>
            <td>{{ $confirmedIndent->getUniqueENQNumber() }}</td>
            <td>{{ $confirmedIndent->customer_name }}</td>
            <td>{{ $confirmedIndent->company_name }}</td>
            <td>{{ $confirmedIndent->number_1 }}</td>
            <td>{{ $confirmedIndent->pickupLocation ? $confirmedIndent->pickupLocation->district : 'N/A' }}</td>
            <td>{{ $confirmedIndent->dropLocation ? $confirmedIndent->dropLocation->district : 'N/A' }}</td>
            <td>{{ $confirmedIndent->materialType->name }}</td>
            <td>{{ $confirmedIndent->truckType->name }}</td>
            <td>@if($confirmedIndent->indentRate->isNotEmpty())
                {{ $confirmedIndent->indentRate->sortBy('rate')->first()->rate }}
                @else
                N/A
                @endif
            </td>
            <td>
                @if(optional($confirmedIndent->customerRate)->rate)
                {{ $confirmedIndent->customerRate->rate }}
                @else
                No customer rate found.
                @endif
            </td>
            <td>{{ $confirmedIndent->remarks }}</td>
            <td>

                <button type="button" class="btn btn-sm" style="font-size:8px;background-color:#FFF78A" data-toggle="modal" data-target="#confirmDeleteModal">
                    Lose
                </button>

                <!-- Modal -->
                <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="confirmDeleteModalLabel">Confirm Delete</h5>
                            </div>
                            <div class="modal-body">
                                <form class="delete-form" action="{{ route('indents.destroy', $confirmedIndent->id) }}" method="POST">
                                    @method('DELETE')
                                    @csrf
                                    <div class="form-group">
                                        <label for="cancelReason" class="fw-bolder">Cancel Reason:</label>
                                        <select name="cancelReason" id="cancelReason" class="form-control">
                                            <option value="">Select a reason</option>
                                            <option value="Not Responding">Not Responding</option>
                                            <option value="Material not ready">Material not ready</option>
                                            <option value="Duplicate Enquiry">Duplicate Enquiry</option>
                                            <option value="Unavailability of vehicle">Unavailability of vehicle</option>
                                            <option value="Trip Postponed">Trip Postponed</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-danger float-end mt-2">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


<script>
    function submitForm() {
        // Submit the form when the "Delete" button in the modal is clicked
        document.getElementById('loseForm').submit();
    }

    // Show/hide the remarks field in the modal based on the button click
    $('#confirmModal').on('shown.bs.modal', function() {
        $('#remarks').focus();
    });

    $('#confirmModal').on('hidden.bs.modal', function() {
        $('#remarks').val(''); // Clear the textarea when the modal is closed
    });
</script>
@endsection