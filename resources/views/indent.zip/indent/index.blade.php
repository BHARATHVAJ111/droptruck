    <!-- resources/views/indents/index.blade.php -->

    @extends('layouts.sidebar')<!-- Assuming you have a layout file -->

    @section('content')
    <style>
        .btn-warning.custom-active {
            background: linear-gradient(135deg, #007bff, #8a2be2);
            color: #fff;
            border: #8a2be2;
        }

        .small-input {
            width: 150px;
            /* Adjust the width as needed */
            font-size: 0.8rem;
            /* Adjust the font size as needed */
        }
        .circle-badge {
        border-radius: 50%;
    }

        .bg-gradient-info {
            background-image: radial-gradient(515px at 48.7% 52.8%, rgb(239, 110, 110) 0%, rgb(230, 25, 25) 46.5%, rgb(154, 11, 11) 100.2%);
        }
    </style>

    <div class="d-flex justify-content-between">
        <div class="m-3">
            <a href="{{ route('indents.index') }}" class="btn btn-warning custom-active" style="font-size: 12px; padding: 5px 10px;position: relative;">Unquoted
            <span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
            {{ $indents->count() }}
    </span>
        </a>
            <a href="{{ route('fetch-last-two-details') }}" class="btn btn-warning " style="font-size: 12px; padding: 5px 10px;position: relative;">Quoted<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
            {{ $quotedIndents }}
    </span></a>
            <a href="{{ route('confirmed_locations')}}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px;position: relative;">Confirmed<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
            {{ $confirmedIndents }}
    </span></a>
            <a href="{{ route('canceled-indents') }}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px;position: relative;">Cancel<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
            {{ $canceledIndents }}
    </span></a>
        </div>
    </div>
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    
@if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif
    <table class="table table-bordered table-striped table-hover" style="font-size:8px;">
        <thead>
            <tr>
                <th class="bg-gradient-info text-light">Enq No</th>
                <th class="bg-gradient-info text-light">Pickup Location</th>
                <th class="bg-gradient-info text-light">Drop Location</th>
                <th class="bg-gradient-info text-light">Truck type</th>
                <th class="bg-gradient-info text-light">Body type</th>
                <th class="bg-gradient-info text-light">Weight</th>
                <th class="bg-gradient-info text-light">Material Type</th>
                <th class="bg-gradient-info text-light">HardCopy</th>
                <th class="bg-gradient-info text-light">Remarks</th>
                <th class="bg-gradient-info text-light">Source of Lead</th>
                <th class="bg-gradient-info text-light">Salesperson</th>
                <th class="bg-gradient-info text-light">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($indents as $indent)
            <tr>
                <td>{{ $indent->getUniqueENQNumber() }}</td>
                <td>{{ $indent->pickupLocation ? $indent->pickupLocation->district : 'N/A' }}</td>
                <td>{{ $indent->dropLocation ? $indent->dropLocation->district : 'N/A' }}</td>

                <td>{{ $indent->truckType ? $indent->truckType->name : 'N/A' }}</td>
                <td>{{ $indent->body_type }}</td>
                <td>{{ $indent->weight }} {{ $indent->weight_unit }}</td>

                <td>{{ $indent->materialType ? $indent->materialType->name : 'N/A' }}</td>

                <td>{{ $indent->pod_soft_hard_copy }}</td>
                <td>{{ $indent->remarks }}</td>
                <td>{{ $indent->source_of_lead }}</td>
                <td>{{ $indent->user->name }}</td>
                <td class="d-flex">
                    @if(auth()->user()->role_id == 1 || auth()->user()->role_id == 2 || auth()->user()->role_id == 3)
                    <div>@include('indent.delete')</div>
                    <a href="{{ route('indents.show', $indent->id) }}" class="btn"><i class="fa fa-eye" style="font-size:8px;color:darkblue"></i></a>
                    <div>@include('indent.edit')</div>
                    @endif
                    @if(auth()->user()->role_id == 4)
                    <div>@include('rate')</div>
                    @endif
                </td>
            </tr>
            @endforeach

        </tbody>
    </table>

    @endsection