@extends('layouts.sidebar')

@section('content')
<style>
    th {
        color: blueviolet;
    }

    .btn-warning.custom-active {
        background: linear-gradient(135deg, #007bff, #8a2be2);
        color: #fff;
        border: #8a2be2;
    }

    .circle-badge {
        border-radius: 50%;
    }
    .bg-gradient-info {
        background-image: radial-gradient(515px at 48.7% 52.8%, rgb(239, 110, 110) 0%, rgb(230, 25, 25) 46.5%, rgb(154, 11, 11) 100.2%);
    }

</style>
<div class="m-3">
    <a href="{{ route('indents.index') }}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px; position: relative;">Unquoted<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
        {{ $unquotedIndents->count() }}
    </span></a>
    <a href="{{ route('fetch-last-two-details') }}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px; position: relative;">Quoted<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
        {{ $quotedIndents->count() }}
    </span></a>
    <a href="{{ route('confirmed_locations')}}" class="btn btn-warning" style="font-size: 12px; padding: 5px 10px;position: relative;">Confirmed<span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
        {{ $confirmedIndents }}
    </span></a>
    <a href="{{ route('canceled-indents') }}" class="btn btn-warning custom-active" style="font-size: 12px; padding: 5px 10px; position: relative;">
    Cancel
    <span class="badge badge-primary circle-badge text-light" id="canceledIndentsCount" style="position: absolute; top: -10px; right: -10px; background: linear-gradient(45deg, #F31559, #F6635C);">
        {{ $canceledIndents->count() }}
    </span>
</a>



</div>

<table class="table table-bordered table-stripped" style="font-size:8px;">
    <thead>
        <tr>
            <th class="bg-gradient-info text-light">ENQ Number</th>
            <th class="bg-gradient-info text-light">Pickup Location</th>
            <th class="bg-gradient-info text-light">Drop Location</th>
            <th class="bg-gradient-info text-light">Material Type</th>
            <th class="bg-gradient-info text-light">Reason</th>
            <th class="bg-gradient-info text-light">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($canceledIndents as $indent)
        <tr>
            <td>{{ $indent->getUniqueENQNumber() }}</td>
            <td>{{ $indent->pickupLocation ? $indent->pickupLocation->district : 'N/A' }}</td>
            <td>{{ $indent->dropLocation ? $indent->dropLocation->district : 'N/A' }}</td>
            <td>{{ $indent->materialType ? $indent->materialType->name : 'N/A' }}</td>
            <td>
        @if(optional($indent->cancelReasons)->isNotEmpty())
            @foreach($indent->cancelReasons as $reason)
            {{ $reason->reason }}
            @endforeach
        @else
        N/A
        @endif
    </td>
            <!-- <td>{{ $indent->cancelReasons->isNotEmpty() ? $indent->cancelReasons->pluck('reason')->implode(', ') : 'No Cancel Reason Available' }}</td> -->
            <td>
                <form action="{{ route('restore-canceled-indent', ['id' => $indent->id]) }}" method="POST" style="display: inline;">
                    @csrf
                    @method('POST')
                    <button type="submit" class="btn btn-sm"><i class="fa fa-recycle" style="font-size:8px;"></i></button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection