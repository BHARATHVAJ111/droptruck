<button type="button" class="btn delete-button" data-indent-id="{{ $indent->id }}" data-bs-toggle="modal" data-bs-target="#deleteConfirmationModal_{{ $indent->id }}">
    <i class="fa fa-trash" style="font-size:8px;color:red" aria-hidden="true"></i>
</button>

<div class="modal fade" id="deleteConfirmationModal_{{ $indent->id }}" tabindex="-1" role="dialog" aria-labelledby="cancelModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <form action="{{ route('indents.destroy', $indent->id) }}" method="POST">
            @method('DELETE')
            @csrf
          <div class="modal-header">
            <h5 class="modal-title" id="cancelModalLabel">Select Reason for Delete</h5>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label for="cancelReason">Select Reason for Delete</label>
              <select class="form-control" id="cancelReason" name="cancelReason">
                <option value="Not Responding">Not Responding</option>
                <option value="Material not ready">Material not ready</option>
                <option value="Duplicate Enquiry">Duplicate Enquiry</option>
                <option value="Unavailability of vehicle">Unavailability of vehicle</option>
                <option value="Trip Postponed">Trip Postponed</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-danger">Confirm Delete</button>
          </div>
        </form>
      </div>
    </div>
</div>